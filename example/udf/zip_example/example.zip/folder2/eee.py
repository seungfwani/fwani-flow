def printer():
    print("this is eee printer")
    return "ok"
