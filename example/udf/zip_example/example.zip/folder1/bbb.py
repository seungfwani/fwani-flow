def printer():
    print("this is bbb printer")
    return "ok"
