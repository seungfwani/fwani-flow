from folder1.folder3 import ddd


def printer():
    print("this is ccc printer")
    print("===== call ddd printer ====")
    ddd.printer()
    return "ok"
