def printer():
    print("this is ddd printer")
    return "ok"
