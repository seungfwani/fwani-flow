import os.path
import sys
from pathlib import Path

# Add the parent path of aaa.py to sys.path
print(Path("./example/udf/zip_example/aaff").resolve())
# sys.path.append(str(Path(__file__).resolve().parent))